def test_hello_world(dut):
    dut.expect('Hello Arduino!')
