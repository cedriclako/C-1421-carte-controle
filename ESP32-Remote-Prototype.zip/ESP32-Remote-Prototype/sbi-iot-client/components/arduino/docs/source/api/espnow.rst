#######
ESP-NOW
#######

ESP-NOW is a fast, connectionless communication technology featuring a short packet transmission.
ESP-NOW is ideal for smart lights, remote control devices, sensors and other applications. 

Example
-------

Resources
---------

* `ESP-NOW`_ (User Guide)

.. _ESP-NOW: https://www.espressif.com/sites/default/files/documentation/esp-now_user_guide_en.pdf
