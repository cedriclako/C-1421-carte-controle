#ifndef _MISC_UTILS_H_
#define _MISC_UTILS_H_

#include <stdint.h>
#include "misc_utils.h"

int32_t MISCUTIL_PrettyHexaString(char* dst, uint32_t u32DstLen, const uint8_t u8Inputs[], uint32_t u32InputLen);

#endif