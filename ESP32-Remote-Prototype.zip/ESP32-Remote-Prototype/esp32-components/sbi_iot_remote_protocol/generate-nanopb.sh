cd protobuf/
../../../tools-exe/nanopb/generator/nanopb_generator.py SBI.iot.proto SBI.iot.common.proto --output-dir ../
