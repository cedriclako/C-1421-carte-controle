
# ttf2bin

Convert ttf file to binary array


