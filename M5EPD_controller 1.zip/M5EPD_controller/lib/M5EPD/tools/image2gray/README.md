# image2gray

Convert the image to a 4bit grayscale array. Please run this script in the image directory, it will be automatically detected and converted. Support .png/.bmp/.jpg
