#ifndef _FRAME_H_
#define _FRAME_H_

#include "frame_home.h"
#include "frame_sleep.h"
#include "frame_menu.h"
#include "frame_wifiscan.h"
#include "frame_livedata.h"

#endif